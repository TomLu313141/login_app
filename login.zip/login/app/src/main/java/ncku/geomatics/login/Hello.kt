package ncku.geomatics.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Hello : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hello)
    }

    val userId = intent.getStringExtra("user_id")
    val emailId = intent.getStringExtra("email_Id")
}